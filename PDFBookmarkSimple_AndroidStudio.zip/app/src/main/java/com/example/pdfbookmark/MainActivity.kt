package com.example.pdfbookmark

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private var renderer: PdfRenderer? = null
    private var fd: ParcelFileDescriptor? = null
    private var page = 0
    private var uri: Uri? = null
    private val prefs by lazy { getSharedPreferences("pdf", MODE_PRIVATE) }

    private lateinit var image: ImageView
    private lateinit var text: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        image = findViewById(R.id.pageImage)
        text = findViewById(R.id.pageText)

        findViewById<Button>(R.id.openButton).setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "application/pdf"; addCategory(Intent.CATEGORY_OPENABLE)
            }, 10)
        }
        findViewById<Button>(R.id.prevButton).setOnClickListener { showPage(page - 1) }
        findViewById<Button>(R.id.nextButton).setOnClickListener { showPage(page + 1) }
        findViewById<Button>(R.id.bookmarkButton).setOnClickListener {
            uri?.let { prefs.edit().putInt("bookmark:${it}", page).apply()
                Toast.makeText(this, "책갈피 저장: ${page + 1}페이지", Toast.LENGTH_SHORT).show() }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) {
            data?.data?.let { openPdf(it) }
        }
    }

    private fun openPdf(u: Uri) {
        closePdf()
        uri = u
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        fd = contentResolver.openFileDescriptor(u, "r")
        renderer = PdfRenderer(fd!!)
        page = prefs.getInt("last:$u", prefs.getInt("bookmark:$u", 0))
        showPage(page)
    }

    private fun showPage(p: Int) {
        val r = renderer ?: return
        if (p !in 0 until r.pageCount) return
        page = p
        val pdfPage = r.openPage(page)
        val w = (resources.displayMetrics.widthPixels * 1.5).toInt()
        val h = (w * pdfPage.height / pdfPage.width.toFloat()).toInt()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        pdfPage.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        pdfPage.close()
        image.setImageBitmap(bmp)
        text.text = "${page + 1} / ${r.pageCount}"
        uri?.let { prefs.edit().putInt("last:$it", page).apply() }
    }

    override fun onPause() {
        super.onPause()
        uri?.let { prefs.edit().putInt("last:$it", page).apply() }
    }

    override fun onDestroy() {
        super.onDestroy()
        closePdf()
    }

    private fun closePdf() {
        renderer?.close(); renderer = null
        fd?.close(); fd = null
    }
}
