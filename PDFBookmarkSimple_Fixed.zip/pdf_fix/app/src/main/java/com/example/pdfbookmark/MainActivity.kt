package com.example.pdfbookmark

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    companion object {
        private const val OPEN_PDF = 10
        private const val PREFS = "pdf_bookmark"
    }

    private var renderer: PdfRenderer? = null
    private var fd: ParcelFileDescriptor? = null
    private var page = 0
    private var uri: Uri? = null
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    private lateinit var image: ImageView
    private lateinit var text: TextView
    private lateinit var prev: Button
    private lateinit var next: Button
    private lateinit var bookmark: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        image = findViewById(R.id.pageImage)
        text = findViewById(R.id.pageText)
        prev = findViewById(R.id.prevButton)
        next = findViewById(R.id.nextButton)
        bookmark = findViewById(R.id.bookmarkButton)

        findViewById<Button>(R.id.openButton).setOnClickListener {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/pdf"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }, OPEN_PDF
            )
        }

        prev.setOnClickListener { showPage(page - 1) }
        next.setOnClickListener { showPage(page + 1) }
        bookmark.setOnClickListener { saveBookmark() }
        updateButtons()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == OPEN_PDF && resultCode == RESULT_OK) {
            data?.data?.let { openPdf(it) }
        }
    }

    private fun openPdf(u: Uri) {
        closePdf()
        uri = u
        try {
            contentResolver.takePersistableUriPermission(
                u,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
            // Some document providers do not support persisted permissions.
        }

        try {
            val newFd = contentResolver.openFileDescriptor(u, "r")
                ?: throw IllegalStateException("PDF 파일을 열 수 없습니다")
            fd = newFd
            renderer = PdfRenderer(newFd)

            val key = u.toString()
            page = prefs.getInt("last:$key", prefs.getInt("bookmark:$key", 0))
                .coerceIn(0, renderer!!.pageCount - 1)
            showPage(page)
        } catch (e: Exception) {
            closePdf()
            uri = null
            text.text = "PDF를 열 수 없습니다"
            updateButtons()
            Toast.makeText(this, "PDF 열기 실패: ${e.message ?: "알 수 없는 오류"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showPage(target: Int) {
        val r = renderer ?: return
        if (target !in 0 until r.pageCount) return

        try {
            val pdfPage = r.openPage(target)
            val display = resources.displayMetrics
            val maxWidth = (display.widthPixels * 1.25f).toInt().coerceAtLeast(600)
            val maxHeight = (display.heightPixels * 1.25f).toInt().coerceAtLeast(900)
            val scale = minOf(
                maxWidth.toFloat() / pdfPage.width.toFloat(),
                maxHeight.toFloat() / pdfPage.height.toFloat()
            )
            val width = (pdfPage.width * scale).toInt().coerceAtLeast(1)
            val height = (pdfPage.height * scale).toInt().coerceAtLeast(1)

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(Color.WHITE)
            pdfPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            pdfPage.close()

            image.setImageBitmap(bitmap)
            image.visibility = View.VISIBLE
            page = target
            text.text = "${page + 1} / ${r.pageCount}"
            uri?.let { prefs.edit().putInt("last:${it}", page).apply() }
            updateButtons()
        } catch (e: Exception) {
            text.text = "${target + 1} / ${r.pageCount} · 표시 오류"
            updateButtons()
            Toast.makeText(this, "페이지 표시 오류: ${e.message ?: "알 수 없는 오류"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveBookmark() {
        val u = uri ?: return
        prefs.edit().putInt("bookmark:$u", page).apply()
        Toast.makeText(this, "책갈피 저장: ${page + 1}페이지", Toast.LENGTH_SHORT).show()
    }

    private fun updateButtons() {
        val count = renderer?.pageCount ?: 0
        prev.isEnabled = count > 0 && page > 0
        next.isEnabled = count > 0 && page < count - 1
        bookmark.isEnabled = count > 0
    }

    override fun onPause() {
        super.onPause()
        uri?.let { prefs.edit().putInt("last:$it", page).apply() }
    }

    override fun onDestroy() {
        closePdf()
        super.onDestroy()
    }

    private fun closePdf() {
        try { renderer?.close() } catch (_: Exception) {}
        renderer = null
        try { fd?.close() } catch (_: Exception) {}
        fd = null
    }
}
